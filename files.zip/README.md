# Invoice Management App

This is a simple web application for managing invoices.

## Technologies Used

- **Frontend**: React.js
- **Backend**: Node.js (Express.js)
- **Database**: MongoDB

## Setup Instructions

### Backend

1. Navigate to the `backend` directory:
   ```sh
   cd backend